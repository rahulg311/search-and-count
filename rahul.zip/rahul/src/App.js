import logo from './logo.svg';
import './App.css';
import{ Child} from './comonent.js/Child';
import { createContext } from 'react';
import Posts from './comonent.js/Main';
const Firstname =  createContext();
const  Lastname = createContext()
function App() {
 
  return (
    <div className="App">
      <Firstname.Provider value={"guptag"} >
        <Lastname.Provider value={"....."} >
            <Child/>
        
        </Lastname.Provider>
     </Firstname.Provider>
     <Posts/>
    </div>
  );
}

export default App;

export  {Firstname, Lastname};
