import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { Card, Input } from 'semantic-ui-react'
export default function Posts() {
    const [APIData, setAPIData] = useState([])
    const[serach,setSearch] = useState("")
    useEffect(() => {
        axios.get(`https://jsonplaceholder.typicode.com/users`)
            .then((response) => {
                setAPIData(response.data);
            })
    }, [])

    return (
        <div style={{ padding: 20 }}>
            <Input icon='search'
           
                placeholder='Search...'
                value={serach}
                onChange={(e) => setSearch(e.target.value)}

            />
            <Card.Group itemsPerRow={3} style={{ marginTop: 20 }}>
                {APIData.filter((val) =>{
                    if(serach == "")
                    {
                        return val;
                    }
                    else if (val.email.toLowerCase().includes(serach.toLowerCase())){
                        return val;
                    }
                }).map((item) => {
                    return (
                        <Card>
                         {
                            serach ?    <Card.Content>
                           <a href={item.id} >  <Card.Header>{item.name}</Card.Header>
                            <Card.Description >
                                {item.email}
                              
                            </Card.Description>
                            </a>
                        </Card.Content> : null
                         }
                        </Card>

                    )
                })}
            </Card.Group>
        </div>
    )
}