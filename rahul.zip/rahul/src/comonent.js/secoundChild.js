import React, { useContext, useState } from 'react';
import ImageUploading from 'react-images-uploading';
import { Firstname, Lastname } from '../App';

export function SecoundChild(props) {
 const fname = useContext(Firstname);
 const laname = useContext(Lastname);

const [count, setCount] = useState(0)

const submit = (e) =>{
  e.preventDefault()
  setClick(!click);
  if (click === true) {
    setCount(count +1);
  
  } else {
    setCount(count -1);
  
  }

  
}

// console.log(count)
props.expetdata(count)
const [click, setClick] = useState(true)

const total = () =>{
  setClick(count + 1)
}

console.log("pappppppppppppp", click)

  return (
    <>
   
    <div>
      <p>{click}</p>
    <h1>{count} {fname} {laname}</h1>
   

<button type='button' onClick={() => setCount(count + 1 )}>increment</button>
<button type='button' onClick={() => setCount((c) => Math.max(c -1 , 4) )}>decrement</button>
</div>
    </>
   
  );
}