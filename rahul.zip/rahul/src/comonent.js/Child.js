import React, { useState } from 'react';
import ImageUploading from 'react-images-uploading';
import { SecoundChild } from './secoundChild';

export function Child(props) {
  const [updates,setUpdates] = useState("")

const getData =(datass) =>{
console.log(datass)
setUpdates(datass)
}

  return (
   <>
   <h1>{updates}</h1>
   <SecoundChild expetdata={getData}/>
    </>
   
  );
}